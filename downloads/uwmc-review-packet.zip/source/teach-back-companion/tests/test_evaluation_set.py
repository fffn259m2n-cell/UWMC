"""The labelled development set must not regress.

These cases were written by an independent adversarial reviewer and then used to tune
the rules, so the numbers here are *development* results, not an accuracy estimate.
The held-out set (eval/heldout_set.json) is measured separately and never tuned on.
"""
from pathlib import Path

from teachback.evaluation import score

DEV = Path(__file__).resolve().parents[1] / "eval" / "dev_set.json"


def test_dev_set_does_not_regress():
    r = score(DEV)
    assert r["teachback"]["sensitivity"] >= 0.99 and r["teachback"]["specificity"] >= 0.99
    assert r["fidelity"]["sensitivity"] >= 0.99 and r["fidelity"]["specificity"] >= 0.99
    assert r["safety_net"]["E_reached"] == 1.0 and r["safety_net"]["C_reached"] == 1.0
    for k in ("E", "C", "M"):
        assert r["safety"][k]["rate"] == 1.0, (k, r["misses"]["safety"])
    assert r["safety"]["N"]["rate"] >= 0.9


def test_cli_prints_safety_net(capsys):
    import json

    from teachback.cli import main
    main(["evaluate-set", str(DEV)])
    out = json.loads(capsys.readouterr().out)
    assert {"teachback", "fidelity", "safety", "safety_net"} <= out.keys()
